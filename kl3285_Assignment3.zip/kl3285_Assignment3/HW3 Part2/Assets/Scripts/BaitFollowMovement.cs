using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaitFollowMovement : MonoBehaviour
{

    // TODO: Create a script that causes the bait to mirror translations of the rod
    // I.e., Update()

    public Transform rodEndTransform;
    public Transform baitTransform;

    // relative movements between above transforms

    // This script should only activate once the rod hits plane surface or pond
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
