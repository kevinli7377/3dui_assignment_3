using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;
using System;

public class LoadScene : MonoBehaviour
{

    public GameStateManager _gameStateManager;
    public GameObject controllerReference;

    public GameObject loadInstructionUI;

    private bool hasLoaded = false;
    private string csvFileName = "HW3_scene";
    private TextAsset csvFile;

    private bool canLoad = false;

    private GameObject transferReferenceObject; // To transfer from Part1 CSV

    void Start()
    {
        loadInstructionUI.SetActive(true);
        StartCoroutine(DelayLoad());
    }

    IEnumerator DelayLoad()
    {
        yield return new WaitForSeconds(1);
        canLoad = true;
    }

    private void Update()
    {
        if (hasLoaded || !canLoad) return;

        if (OVRInput.Get(OVRInput.RawButton.A))
        {
            LoadCSV(controllerReference);
            hasLoaded = true;
            controllerReference.SetActive(false);
            loadInstructionUI.SetActive(false);
            _gameStateManager.StartGame();
        }
    }


    public void LoadCSV(GameObject placedControllerReference) // Could take in the controller reference object transform. 
    {
        if (hasLoaded) return;

        // TODO: Find csvFile in resources folder instead of finding it in the assets folder

        csvFile = Resources.Load<TextAsset>(csvFileName);


        if (csvFile == null)
        {
            Debug.LogError("CSV File is not assigned.");
            return;
        }

        transferReferenceObject = new GameObject("TransferReferenceObject");

        string[] lines = csvFile.text.Split('\n');

        for (int i = 1; i < lines.Length-1; i++){ // skip header line and don't read in final empty line
            string[] values = lines[i].Split(',');
            Debug.Log(values[0]);

            if (values.Length < 10)
            {
                Debug.LogError("Line format is incorrect: " + lines[i]);
                continue;
            }

            LoadObjectFromCSVLine(values);
        }


        transferReferenceObject.transform.position = placedControllerReference.transform.position;

        Quaternion currentRotation = transferReferenceObject.transform.rotation;
        Vector3 currentEulerAngles = currentRotation.eulerAngles;
        float newYRotation = placedControllerReference.transform.rotation.eulerAngles.y;
        //float newYRotation = placedControllerReference.transform.localEulerAngles.y; 


        transferReferenceObject.transform.rotation = Quaternion.Euler(currentEulerAngles.x, newYRotation, currentEulerAngles.z);

        // Start GameStateManager
        hasLoaded = true;
        _gameStateManager.StartGame();

    }

    private void LoadObjectFromCSVLine(string[] values)
    {
        // Get GameObject transform details
        string tag = values[0];
        Vector3 localPosition = new Vector3(float.Parse(values[1]), float.Parse(values[2]), float.Parse(values[3]));
        Quaternion localRotation = Quaternion.Euler(float.Parse(values[4]), float.Parse(values[5]), float.Parse(values[6]));
        Vector3 localScale = new Vector3(float.Parse(values[7]), float.Parse(values[8]), float.Parse(values[9]));

        GameObject prefab;

        if (tag == "Boat")
        {
            prefab = Resources.Load<GameObject>($"Prefabs/Boat_setup"); // Spawn separate boat
        }
        else
        {
            prefab = Resources.Load<GameObject>($"Prefabs/{tag}"); // All Prefabs are in Assets/Resources
        }

        if (prefab == null)
        {
            Debug.Log("Could not find prefab");
            Debug.Log($"Prefabs/{tag}");
        }

        if (prefab != null)
        {
            GameObject obj = Instantiate(prefab, transferReferenceObject.transform);
            obj.transform.localPosition = localPosition;
            obj.transform.localRotation = localRotation;
            obj.transform.localScale = localScale;
        }
    }

}
