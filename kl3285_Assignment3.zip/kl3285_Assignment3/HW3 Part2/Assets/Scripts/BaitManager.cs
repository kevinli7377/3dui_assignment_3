//using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BaitManager : MonoBehaviour
{
    public List<GameObject> baits;
    public GameObject baitPrefab;

    public List<InitialState> baitInitialStates = new List<InitialState>();

    public class InitialState
    {
        public Vector3 initialPosition;
        public Quaternion initialRotation;
    }

    private GameObject chosenBait;

    // ---------------------------------------------------------------------------------------------------

    public void StartBaitManager()
    {
        InitializeBait();
        ChooseBait();
    }

    private void ChooseBait()
    {
        // Randomnly choose a bait from the list and change its bait.isChosen = true
        // and turn on its highlight.
        if (baits.Count == 0) return;

        if (chosenBait != null) // in case
        {
            Transform highlight = chosenBait.transform.Find("Highlight");
            if (highlight != null) highlight.gameObject.SetActive(false); // turn off previous selection if any
            chosenBait.GetComponentInChildren<Bait>().isChosen = false; 
        }

        int index = Random.Range(0, baits.Count);
        chosenBait = baits[index];

        Transform newhighlight = chosenBait.transform.Find("Highlight");
        if (newhighlight != null) newhighlight.gameObject.SetActive(true); // turn on
        chosenBait.GetComponentInChildren<Bait>().isChosen = true;
    }

    private void InitializeBait()
    {
        // Iterate through scene and find all bait objects and append to the list

        baits.Clear();

        GameObject[] baitObjects = GameObject.FindGameObjectsWithTag("Bait");
        foreach (GameObject baitObj in baitObjects)
        {
            baits.Add(baitObj);

            InitialState initialState = new InitialState
            {
                initialPosition = baitObj.transform.position,
                initialRotation = baitObj.transform.rotation,
            };
            baitInitialStates.Add(initialState);
        }
    }

    public void ResetBait()
    {
        for (int i = 0; i < baits.Count; i++) // Iterate through all baits and reset to initial transform
        {
            if (baits[i] != null)
            {
                baits[i].gameObject.SetActive(true);
                baits[i].transform.position = baitInitialStates[i].initialPosition;
                baits[i].transform.rotation = baitInitialStates[i].initialRotation;

                // Deactivate highlight or selection states as needed
                Transform highlight = baits[i].transform.Find("Highlight");
                if (highlight != null)
                    highlight.gameObject.SetActive(false); // turn off highlight

                baits[i].GetComponentInChildren<Bait>().isChosen = false; // reset chosen state
            }
        }

        // After resetting all baits, choose a new bait
        ChooseBait();
    }
}
