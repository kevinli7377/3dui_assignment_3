using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bait : MonoBehaviour
{
    // Start is called before the first frame update
    public bool isChosen;
    public FishingRodManager fishingRodManager;

    private void Start()
    {
        fishingRodManager = FindObjectOfType<FishingRodManager>();

        if (fishingRodManager == null)
        {
            Debug.LogError("FishingRodManager not found in the scene.");
        }

    }

    private void OnTriggerEnter(Collider other) 
    {

        //Debug.LogError("hit rock fish or bottle");

        if (other.CompareTag("Rock")|| other.CompareTag("Fish")|| other.CompareTag("Bottle")|| other.CompareTag("Can"))
        {
            // Tell rod to reel
            fishingRodManager.PromptReel(other);

        }

    }

    private void OnTriggerExit(Collider other)
    {
        //Debug.LogError("stopped hitting rock fish or bottle");
        if (other.CompareTag("Rock") || other.CompareTag("Fish") || other.CompareTag("Bottle") || other.CompareTag("Can"))
        {
            // Tell rod no need to reel
            fishingRodManager.StopReelPrompt();
        }

    }
}
