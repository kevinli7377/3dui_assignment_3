using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fish : MonoBehaviour
{
    public int points = 3;

    public float speed = 0.1f; // speed of fish
    public float directionChangeInterval = 10.0f;

    public Vector3 targetDirection;

    private void Start()
    {
        ChangeDirectionRandomly();
        StartCoroutine(ChangeDirectionPeriodically());
    }

    void Update()
    {
        Swim();
    }

    private void ChangeDirectionRandomly()
    {
        float angle = Random.Range(0f, 2*Mathf.PI);
        float targetX = Mathf.Cos(angle);
        float targetZ = Mathf.Sin(angle);

        targetDirection = new Vector3(targetX, 0, targetZ).normalized;
    }

    private IEnumerator ChangeDirectionPeriodically()
    {
        while (true)
        {
            ChangeDirectionRandomly();
            yield return new WaitForSeconds(directionChangeInterval);
        }
    }

    private void Swim()
    {
        transform.Translate(targetDirection * speed * Time.deltaTime, Space.World);
        if (targetDirection != Vector3.zero) // Rotate fish to match movement direction
        {
            Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
            targetRotation *= Quaternion.Euler(0, 90, 0);
            transform.rotation = targetRotation;// Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime);
        }
    }

    //private void OnCollisionEnter(Collision collision)
    //{
    //    // change direction
    //    //ChangeDirectionRandomly();

    //    Debug.Log("OnCollisionEnter");
    //    targetDirection = -targetDirection;
    //}


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pond")) return;

        // change direction
        //Debug.Log("OnTriggerEnter");
        //Debug.Log(other.tag);
        targetDirection = -targetDirection;
    }
    private void OnTriggerExit(Collider other) // Check if fish exits pond
    {
        if (!other.gameObject.CompareTag("Pond")) return;

        Vector3 directionToCenter = other.bounds.center - transform.position;

        //Debug.Log("OnTriggerExit");
        targetDirection = directionToCenter.normalized; // this isn't working properly
        transform.position = other.bounds.ClosestPoint(transform.position);
    }
}
