using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishingLine : MonoBehaviour
{
    public Transform startPoint;
    public Transform endPoint;
    private LineRenderer lineRenderer;


    private void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
    }

    //-----------------------------------------------------------

    private void Update()
    {
        if (lineRenderer != null && startPoint != null && endPoint != null)
        {
            lineRenderer.SetPosition(0, startPoint.position);
            lineRenderer.SetPosition(1, endPoint.position);
        }
    }

    //-----------------------------------------------------------

    public void SetLine(Transform _startPoint, Transform _endPoint)
    {
        startPoint = _startPoint;
        endPoint = _endPoint;
    }

    public void ResetLine()
    {
        endPoint = startPoint;
    }
}
