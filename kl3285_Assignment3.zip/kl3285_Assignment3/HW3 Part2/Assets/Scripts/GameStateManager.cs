using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;

using UnityEngine.SceneManagement;

public class GameStateManager : MonoBehaviour
{

    public int score;
    public bool isGameActive;
    public bool sceneLoaded = false;
    public int numFishInScene;

    public GameObject gameCompleteUI;
    public GameObject scoreUI;

    public BaitManager baitManager;
    public FishingRodManager fishingRodManager;

    public GameObject loadSceneManager;

    private void Update()
    {
        if (isGameActive || !sceneLoaded) return;

        if (OVRInput.Get(OVRInput.RawButton.A))
        {
            Reset();
        }
    }

    public void StartGame()
    {
        score = 0;
        isGameActive = true;
        numFishInScene = GetNumFishInScene();

        // Initialize UI
        gameCompleteUI.SetActive(false); 
        scoreUI.SetActive(true);

        UpdateScore(score); // score = 0

        // Start all managers
        baitManager.StartBaitManager(); 
        fishingRodManager.StartFishingRodManager();
        sceneLoaded = true;

    }

    private int GetNumFishInScene()
    {
        // Iterate through scene, find all active fish objects and count.
        // make numFishInscene = number of active fish objets, iwth 'Fish' tag

        GameObject[] fishObjects = GameObject.FindGameObjectsWithTag("Fish");
        return fishObjects.Length;
    }

    public void CheckGameStatus()
    {
        if (numFishInScene < 1)
        {
            isGameActive = false;
            GameOver();
        }
    }

    public void UpdateScore(int points)
    {
        if (!isGameActive) return;

        if (points > 0) // Only fish have position points
        {
            numFishInScene -= 1; // update fish if returned score is positive
        }

        score += points;
        CheckGameStatus();

        scoreUI.GetComponent<TextMeshProUGUI>().text =  "Score: " + score.ToString();
    }

    private void GameOver()
    {
        gameCompleteUI.SetActive(true);
    }

    private void Reset()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

}
