using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishingRodManager : MonoBehaviour
{
    public bool hasBait = false;
    public bool hasCaught = false;
    public bool hasCastBait = false;

    public BaitManager baitManager;
    public BaitSpawner baitSpawner;

    public FishingLine fishingLine;

    public GameStateManager gameStateManager;

    public GameObject castBaitTextUI;
    public GameObject reelInstructionTextUI;
    public GameObject attachBaitTextUI;

    public GameObject bait;

    public GameObject baitCollidedObject = null;

    public float buttonPressStartTime;
    public bool isButtonPressed;

    //-----------------------------------------------------------

    public void StartFishingRodManager()
    {
        baitManager = FindObjectOfType<BaitManager>();

        if (baitManager == null)
        {
            Debug.LogError("BaitManager not found in the scene.");
        }

        baitSpawner = GameObject.FindGameObjectWithTag("Rod").GetComponentInChildren<BaitSpawner>();

        if (baitSpawner == null)
        {
            Debug.LogError("BaitSpawner not found in the scene.");
        }

        fishingLine = FindObjectOfType<FishingLine>();

        if (fishingLine == null)
        {
            Debug.LogError("FishingLine not found in the scene.");
        }

        // Show instructions
        TurnOnAttachBaitInstruction();

        isButtonPressed = false;

    }

    //-----------------------------------------------------------

    // UI Functions

    public void TurnOnAttachBaitInstruction()
    {
        attachBaitTextUI.SetActive(true);
    }

    public void TurnOffAttachBaitInstruction()
    {
        attachBaitTextUI.SetActive(false);
    }

    public void TurnOnReelInstruction()
    {
        reelInstructionTextUI.SetActive(true);
    }

    public void TurnOffReelInstruction()
    {
        reelInstructionTextUI.SetActive(false);
    }

    public void TurnOnCastBaitInstruction()
    {
        castBaitTextUI.SetActive(true);
    }

    public void TurnOffCastBaitInstruction()
    {
        castBaitTextUI.SetActive(false);
    }

    //-----------------------------------------------------------

    public void Update()
    {
        if (OVRInput.GetDown(OVRInput.RawButton.A))
        {
            if (hasBait)
            {
                buttonPressStartTime = Time.time;
                isButtonPressed = true;

            }
        }

        if (OVRInput.GetUp(OVRInput.RawButton.A) && isButtonPressed)
        {
            if (hasBait)
            {
                if (!hasCastBait)
                {
                    float holdTime = Time.time - buttonPressStartTime;
                    // force depends on holdtime of A button
                    float force = Mathf.Clamp(holdTime, 1, 10);
                    CastBait(force);
                }
                else
                {
                    Reel();
                }
            }
            isButtonPressed = false;
        }
    }

    //-----------------------------------------------------------

    // Fishing functions
    public void CastBait(float force)
    {
        if (!hasBait && hasCastBait) return;

        TurnOffCastBaitInstruction();

        bait = baitSpawner.SpawnAndShootBait(force);
        hasCastBait = true;
    }

    public void PromptReel(Collider other)
    {
        hasCaught = true;
        reelInstructionTextUI.SetActive(true); 
        baitCollidedObject = other.gameObject;
    }

    public void StopReelPrompt()
    {
        hasCaught = false;
        reelInstructionTextUI.SetActive(false); 
        baitCollidedObject = null;
    }

    public void Reel()
    {
        if (!hasBait || !hasCastBait) return;

        fishingLine.ResetLine();

        Destroy(bait);

        hasCastBait = false;
        hasBait = false;

        baitManager.ResetBait(); // problem here - not all baits are being destroyed in VR but in the play mode it's fine..

        TurnOnAttachBaitInstruction();

        if (!hasCaught) // if nothing has been caught
        {
            StopReelPrompt();
            return;
        }

        if (baitCollidedObject.CompareTag("Fish")) // fish object
        {
            gameStateManager.UpdateScore(baitCollidedObject.GetComponent<Fish>().points); 
        }
        else // enemy object
        {
            gameStateManager.UpdateScore(baitCollidedObject.GetComponent<EnemyObjects>().points); 
        }

        Destroy(baitCollidedObject); // destroy the collided object

        StopReelPrompt();

        if (!gameStateManager.isGameActive)
        {
            TurnOffAttachBaitInstruction();
        }
    }

    public void FitBait() // to be called by baitspawner
    {
        hasBait = true;
        TurnOffAttachBaitInstruction();
        TurnOnCastBaitInstruction();
    }

}
