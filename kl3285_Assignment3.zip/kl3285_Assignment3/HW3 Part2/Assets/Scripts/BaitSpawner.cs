using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaitSpawner : MonoBehaviour
{
    // Attach script to tip of rod

    public GameObject baitPrefab;
    public Transform baitSpawnPoint;
    public GameObject attachedDummyBait; // to show the bait was attached to rod
    public FishingRodManager fishingRodManager;

    public FishingLine fishingLine;

    private GameObject currentBaitInstance;

    private void Start()
    {
        fishingRodManager = FindObjectOfType<FishingRodManager>();

        if (fishingRodManager == null)
        {
            Debug.LogError("FishingRodManager not found in the scene.");
        }
    }

    //-----------------------------------------------------------

    public GameObject SpawnAndShootBait(float force) // Spawns bait at tip of rod
    {
        if (currentBaitInstance != null) Destroy(currentBaitInstance);

        currentBaitInstance = Instantiate(baitPrefab,
            baitSpawnPoint.position,
            baitSpawnPoint.rotation,
            baitSpawnPoint);

        Rigidbody rb = currentBaitInstance.GetComponent<Rigidbody>();
        rb.AddForce(currentBaitInstance.transform.forward * force, ForceMode.VelocityChange);

        attachedDummyBait.SetActive(false); // Turn off dummy bait on

        // Set line
        fishingLine.SetLine(baitSpawnPoint,currentBaitInstance.transform);

        return currentBaitInstance;
    }

    private void OnTriggerEnter(Collider other) // For bait-fitting
    {
        if (other.CompareTag("Bait"))
        {
            Bait otherBait = other.GetComponentInChildren<Bait>();
            if (otherBait && otherBait.isChosen)
            {
                attachedDummyBait.SetActive(true);
                other.gameObject.SetActive(false);
                fishingRodManager.FitBait();
            }
        }
    }
}
