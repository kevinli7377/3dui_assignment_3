using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.Interaction.Toolkit.AR;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class DeleteMode : MonoBehaviour, ICommand
{
    public GameObject enterDeleteModeButton;
    public GameObject exitDeleteModeButton;

    public ARRaycastManager raycastManager;

    private List<ARRaycastHit> raycastHits = new List<ARRaycastHit>();

    public bool isDeletionMode = false;


    public Camera arCamera;

    Stack<TransformData> undoData = new Stack<TransformData>();
    Stack<TransformData> redoData = new Stack<TransformData>();

    void Start()
    {
        enterDeleteModeButton.SetActive(true);
        exitDeleteModeButton.SetActive(false);
    }

    public void toggleButton()
    {
        //enterDeleteMode.SetActive(!enterDeleteMode.activeInHierarchy);
        //exitDeleteMode.SetActive(!enterDeleteMode.activeInHierarchy);
        isDeletionMode = !isDeletionMode;
        if (isDeletionMode)
        {
            EnterDeleteMode();
        } else
        {
            ExitDeleteMode();
        }
    }

    public void EnterDeleteMode()
    {
        DeactivateObjectSelection();
        this.gameObject.SetActive(true);
        exitDeleteModeButton.SetActive(true); // buttons
        enterDeleteModeButton.SetActive(false);
    }

    public void ExitDeleteMode()
    {
        ActivateObjectSelection();
        this.gameObject.SetActive(false);
        exitDeleteModeButton.SetActive(false); // buttons
        enterDeleteModeButton.SetActive(true);
    }

    public void DeactivateObjectSelection()
    {
        ARSelectionInteractableExtended[] objects = FindObjectsOfType<ARSelectionInteractableExtended>();

        // Get all Transform Undo scripts and deactiate. 
        foreach(ARSelectionInteractableExtended obj in objects)
        {
            obj.enabled = false;
        }

    }

    public void ActivateObjectSelection()
    {
        ARSelectionInteractableExtended[] objects = FindObjectsOfType<ARSelectionInteractableExtended>(includeInactive: true);

        foreach (ARSelectionInteractableExtended obj in objects)
        {
            obj.enabled = true;
        }
    }


    public void Execute()
    {
    }

    public void Delete(GameObject obj)
    {
        CommandManager.ExecuteCommand(this);

        TransformData _undoData = new TransformData();

        obj.SetActive(false);

        _undoData.position = obj.transform.position;
        _undoData.rotation = obj.transform.localEulerAngles;
        _undoData.tag = obj.tag;
        _undoData.objectInstance = obj;

        undoData.Push(_undoData);
        redoData.Clear();
    }

    public void Undo()
    {
        if (undoData.Count > 0)
        {
            TransformData _undoData = undoData.Pop();
            _undoData.objectInstance.SetActive(true);
            redoData.Push(_undoData);
        }
    }

    public void Redo()
    {
        if (redoData.Count > 0)
        {
            TransformData _redoData = redoData.Pop();
            _redoData.objectInstance.SetActive(false);
            undoData.Push(_redoData);
        }
    }
}
