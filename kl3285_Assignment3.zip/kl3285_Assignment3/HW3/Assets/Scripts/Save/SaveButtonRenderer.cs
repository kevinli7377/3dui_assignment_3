using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveButtonRenderer : MonoBehaviour
{
    public GameObject saveButton;
    public SaveScene _saveScene;

    private void Update()
    {
        GameObject reference = GameObject.FindGameObjectWithTag("Reference");
        if (reference != null)
        {
            // Object exists, make the save button interactable
            saveButton.SetActive(true);
            _saveScene.referenceObject = reference.transform; // Pass in Reference transform
        }
        else
        {
            // Object does not exist, make the save button non-interactable
            saveButton.SetActive(false);
            _saveScene.referenceObject = null;
        }
    }
}
