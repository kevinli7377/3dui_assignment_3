using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

using TMPro;

public class SaveScene : MonoBehaviour
{
    public Transform referenceObject;

    List<string> savableObjectTags = new List<string> {"Pond","Boat","Fish","Bottle","Can","Rock"};

    //public TextMeshProUGUI text;

    public GameObject saveSceneWindowUI;
    public TextMeshProUGUI savePath;

    private void Start()
    {
        //text = GameObject.FindGameObjectWithTag("Debug").GetComponent<TextMeshProUGUI>();
        saveSceneWindowUI.SetActive(false);
    }

    public void SaveCSV()
    {
        //text.text = "save pressed";
        if (!referenceObject) return;

        //text.text = "reached here in SaveCSV";

        List<string> lines = new List<string>();

        lines.Add("Tag, pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, localScale.x, localScale.y, localScale.z");

        // Save reference first:
        string line = $"Reference,0,0,0,0,0,0," +
                //$"{referenceObject.transform.localEulerAngles.x}," +
                //$"{referenceObject.transform.localEulerAngles.y}," +
                //$"{referenceObject.transform.localEulerAngles.z}," +
                $"{referenceObject.transform.localScale.x}," +
                $"{referenceObject.transform.localScale.y}," +
                $"{referenceObject.transform.localScale.z}";

        lines.Add(line);

        // line: Tag, pos.x, pox.y, pos.z, rot.x, rot.y, ,rot.z, scale.x, scale.y, scale.z

        foreach (var obj in FindObjectsOfType<GameObject>())
        {
            string objTag = obj.tag;

            if (savableObjectTags.Contains(objTag)){
                // Calculate relative position - set y to 0 to account for plane offsets
                Vector3 relativePosition = new Vector3(obj.transform.position.x - referenceObject.position.x,
                                                        obj.transform.position.y - referenceObject.position.y,
                                                        obj.transform.position.z - referenceObject.position.z);

                // Calculate relative orientation in Euler angles
                //Quaternion relativeOrientation = Quaternion.Inverse(referenceObject.rotation) * obj.transform.rotation;
                //Vector3 relativeEulerAngles = relativeOrientation.eulerAngles;

                // Maybe store world rotation
                Vector3 relativeEulerAngles = obj.transform.localEulerAngles;

                // Calculate relative scale
                Vector3 relativeScale = new Vector3(obj.transform.localScale.x,
                                                     obj.transform.localScale.y,
                                                     obj.transform.localScale.z);

                line = $"{objTag}," +
                    $"{relativePosition.x},{relativePosition.y},{relativePosition.z}," +
                    $"{relativeEulerAngles.x},{relativeEulerAngles.y},{relativeEulerAngles.z}," +
                    $"{relativeScale.x},{relativeScale.y},{relativeScale.z}";
                lines.Add(line);
            }
        }

        string filePath = Path.Combine(Application.persistentDataPath, "HW3_scene.csv");
        //text.text = filePath;

        savePath.text = $"Scene saved to {filePath}";

        if (File.Exists(filePath))
        {
            File.Delete(filePath);
        }

        File.WriteAllLines(filePath, lines);

        Debug.Log($"Scene saved to {filePath}");
    }

    public void OnSaveButton()
    {
        SaveCSV();
        RenderSaveWindow();
    }

    private void RenderSaveWindow()
    {
        saveSceneWindowUI.SetActive(true);
    }

    public void TurnOffSaveWindow()
    {
        saveSceneWindowUI.SetActive(false) ;
    }
}
