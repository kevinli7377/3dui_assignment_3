using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.AR;

public class TransformDelete : MonoBehaviour
{

    public ARSelectionInteractable interactable;
    public DeleteManager _deleteManager;


    void Start()
    {
        GameObject deleteManagerObject = GameObject.FindWithTag("DeleteManager");
        if (deleteManagerObject != null)
        {
            _deleteManager = deleteManagerObject.GetComponent<DeleteManager>();
        }
    }

    private void OnEnable()
    {
        interactable.onSelectEntered.AddListener(AddSelectionToDeleteManager);
        interactable.onSelectExited.AddListener(RemoveSelectionFromDeleteManager);
    }

    private void OnDisable()
    {
        interactable.onSelectEntered.RemoveListener(AddSelectionToDeleteManager);
        interactable.onSelectExited.RemoveListener(RemoveSelectionFromDeleteManager);
    }

    void AddSelectionToDeleteManager(XRBaseInteractor interactor)
    {
        _deleteManager._selectedObject = this.transform.gameObject;
    }

    void RemoveSelectionFromDeleteManager(XRBaseInteractor interactor)
    {
        _deleteManager._selectedObject = null;
    }
}















//public class TransformDelete : MonoBehaviour, ICommand
//{
//    Stack<TransformData> undoData = new Stack<TransformData>();
//    Stack<TransformData> redoData = new Stack<TransformData>();

//    public ARSelectionInteractable interactable;

//    public DeleteManager _deleteManager;

//    //public isPlaceable isplaceable;

//    public DeleteMode deleteMode;

//    void Start()
//    {
//        //GameObject managerObject = GameObject.FindWithTag("PlacementInteractable"); // Assuming it has a unique tag
//        //if (managerObject != null)
//        //{
//        //    isplaceable = managerObject.GetComponent<isPlaceable>();
//        //}

//        GameObject managerObject = GameObject.FindWithTag("DeleteModeManager"); // Assuming it has a unique tag
//        if (managerObject != null)
//        {
//            deleteMode = managerObject.GetComponent<DeleteMode>();
//        }

//        //GameObject deleteManagerObject = GameObject.FindWithTag("DeleteManager"); // Assuming it has a unique tag
//        //if (deleteManagerObject != null)
//        //{
//        //    _deleteManager = deleteManagerObject.GetComponent<DeleteManager>();
//        //}
//    }

//    private void OnEnable()
//    {
//        //interactable.onSelectEntered.AddListener(AddCommand);

//        interactable.onSelectEntered.AddListener(AddSelectionToDeleteManager);
//        interactable.onSelectExited.AddListener(RemoveSelectionFromDeleteManager);
//    }

//    private void OnDisable()
//    {
//        //interactable.onSelectEntered.RemoveListener(AddCommand);

//        interactable.onSelectEntered.RemoveListener(AddSelectionToDeleteManager);
//        interactable.onSelectExited.RemoveListener(RemoveSelectionFromDeleteManager);
//    }

//    void AddSelectionToDeleteManager(XRBaseInteractor interactor)
//    {
//        _deleteManager._selectedObject = this.transform.gameObject;
//    }

//    void RemoveSelectionFromDeleteManager(XRBaseInteractor interactor)
//    {
//        _deleteManager._selectedObject = null;
//    }

//    // Command Manager
//    void AddCommand(XRBaseInteractor interactor)
//    {
//        //if delete mode
//        if (deleteMode.isDeletionMode)
//        {
//            CommandManager.ExecuteCommand(this);

//            TransformData _undoData = new TransformData();
//            GameObject currentObject = this.transform.gameObject; // get the gameobject the selections script is attached to

//            currentObject.SetActive(false);

//            _undoData.position = currentObject.transform.position;
//            _undoData.rotation = currentObject.transform.localEulerAngles;
//            _undoData.tag = currentObject.tag;


//            _undoData.objectInstance = currentObject;

//            // need to turn off the selection

//            // there's a bug -- likely to do with the selection tool
//            // nee to remove selection

//            undoData.Push(_undoData);
//            redoData.Clear();

//            // TODO: need to turn off the selction mesh
//            interactor.interactionManager.CancelInteractableSelection(interactable);
//        }
//    }

//    public void Execute()
//    {
//    }

//    public void Undo()
//    {
//        // create new instance of object and put on stack
//        if (undoData.Count > 0)
//        {
//            TransformData _undoData = undoData.Pop();
//            _undoData.objectInstance.SetActive(true);
//            redoData.Push(_undoData);
//        }
//    }

//    public void Redo()
//    {
//        if (redoData.Count > 0)
//        {
//            TransformData _redoData = redoData.Pop();
//            _redoData.objectInstance.SetActive(false);
//            undoData.Push(_redoData);
//        }
//    }

//}
