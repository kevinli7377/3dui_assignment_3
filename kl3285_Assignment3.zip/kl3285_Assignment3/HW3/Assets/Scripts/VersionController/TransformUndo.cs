using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.AR;

public class TransformUndo : MonoBehaviour, ICommand
{
    Stack<TransformData> undoData = new Stack<TransformData>();
    Stack<TransformData> redoData = new Stack<TransformData>();

    ARSelectionInteractable interactable;

    public ARPlacementInteractableExtended placementInteractable;

    private bool originalIsInPond;

    //public TextMeshProUGUI text;

    public TransformData initialTransformData;

    void Start()
    {
        //text = GameObject.FindGameObjectWithTag("Debug").GetComponent<TextMeshProUGUI>();

        placementInteractable = GameObject.FindGameObjectWithTag("PlacementInteractable").GetComponent<ARPlacementInteractableExtended>();
    }

    // ------------------------------------------------------------------------

    void ICommand.Execute()
    {
        
    }

    void ICommand.Undo()
    {
        if (undoData.Count <= 0) return;

        TransformData _redoData = new TransformData();
        _redoData.position = this.transform.position;
        _redoData.rotation = this.transform.localEulerAngles;

        TransformData _undoData = undoData.Pop();

        ApplyTransformData(_undoData);

        redoData.Push(_redoData);
    }

    void ICommand.Redo()
    {
        if (redoData.Count <= 0) return;

        // save current transform here before applying redo
        TransformData _undoData = new TransformData();
        _undoData.position = this.transform.position;
        _undoData.rotation = this.transform.localEulerAngles;

        TransformData _redoData = redoData.Pop();
        ApplyTransformData(_redoData);

        undoData.Push(_undoData);
    }

    void ApplyTransformData(TransformData _data)
    {
        transform.position = _data.position;
        transform.localEulerAngles = _data.rotation;
    }


    // ------------------------------------------------------------------------

    private void OnEnable()
    {
        interactable = GetComponent<ARSelectionInteractable>();

        interactable.onSelectEntered.AddListener(SaveInitialTransformData);
        interactable.onSelectEntered.AddListener(TurnOffPlacer);

        interactable.onSelectExited.AddListener(UpdateStack);
        interactable.onSelectExited.AddListener(TurnOnPlacer);
    }

    private void OnDisable()
    {
        interactable.onSelectEntered.RemoveListener(SaveInitialTransformData);
        interactable.onSelectEntered.RemoveListener(TurnOffPlacer);

        interactable.onSelectExited.RemoveListener(UpdateStack);
        interactable.onSelectExited.RemoveListener(TurnOnPlacer);
    }

    // ------------------------------------------------------------------------

    void SaveInitialTransformData(XRBaseInteractor arg)
    {
        TransformData data = new TransformData();
        data.position = this.transform.position;
        data.rotation = this.transform.localEulerAngles;
        data.tag = this.tag;
        data.objectInstance = this.gameObject;

        initialTransformData = data;

        ObjectStatus status = this.GetComponent<ObjectStatus>();

        originalIsInPond = status.isInPond;
    }

    // Something funky here - bug; but not sure why

    private void UpdateStack(XRBaseInteractor arg)
    {
        CommandManager.ExecuteCommand(this);
        undoData.Push(initialTransformData);
        redoData.Clear();

        if (!CheckTransformChange()) {
            //text.text += "Updatestack-undo";
            CommandManager.Undo();
        }
    }

    private bool CheckTransformChange()
    {
        ObjectStatus status = GetComponent<ObjectStatus>();

        // Likely problem with status.isInPond != originalIsInPond

        // May need to introduce coroutine for effective update of isinPond status
        // Or, simply have to create a bool for initialsetup, save the object isntance that is never then updated.
        // Maybe include initialIsinPond in the transformdata

        // Likely problem - too fast translations and delection has bug

        if (status.isIntersecting || ((tag == "Fish" || tag == "Boat") && !status.isInPond) || status.isInPond != originalIsInPond)
        {
            //text.text += "\nfalse";
            return false;
        }

        if (Vector3.Distance(transform.position, initialTransformData.position) < 0.01f
            && Quaternion.Angle(Quaternion.Euler(transform.localEulerAngles),
            Quaternion.Euler(initialTransformData.rotation)) < 0.01f)
            return false;

        return true;
    }

    void TurnOffPlacer(XRBaseInteractor arg)
    {
        placementInteractable.enabled = false;
    }

    void TurnOnPlacer(XRBaseInteractor arg)
    {
        placementInteractable.enabled = true;
    }

}

public struct TransformData
{
    public Vector3 position;
    public Vector3 rotation;

    public string tag;
    public GameObject objectInstance;

    //public bool initialIsInPond;
}




/*
 * 
 using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.AR;


// PROBLEM: The problem is that attaching two ICommand scripts to an object is problematic
// calling command.Execute in the commandmanager would cause 2 addcommands to occur

public class TransformUndo : MonoBehaviour, ICommand
{
    Stack<TransformData> undoData = new Stack<TransformData>();
    Stack<TransformData> redoData = new Stack<TransformData>();

    ARSelectionInteractable interactable;

    public ARPlacementInteractableExtended placementInteractable;

    public DeleteMode deleteMode;

    private bool originalIsInPond;

    public TextMeshProUGUI text;

    private TransformData initialTransformData;

    void Start()
    {
        //Debug.Log("Started");
        text = GameObject.FindGameObjectWithTag("Debug").GetComponent<TextMeshProUGUI>();

        placementInteractable = GameObject.FindGameObjectWithTag("PlacementInteractable").GetComponent<ARPlacementInteractableExtended>();

        GameObject managerObject = GameObject.FindWithTag("DeleteModeManager"); // Assuming it has a unique tag
        if (managerObject != null)
        {
            deleteMode = managerObject.GetComponent<DeleteMode>();
        }
    }

    void AddCommand(XRBaseInteractor arg)
    {
        CommandManager.ExecuteCommand(this);

        TransformData data = new TransformData();
        data.position = this.transform.position;
        data.rotation = this.transform.localEulerAngles;

        // Added to support placement and deletion
        data.tag = this.tag;
        data.objectInstance = this.gameObject;

        undoData.Push(data);
        redoData.Clear();
        text.text += "\n Adding Command - TransformUndo";
    }

    void ApplyTransformData(TransformData _data)
    {
        transform.position = _data.position;
        transform.localEulerAngles = _data.rotation;
    }


    void ICommand.Execute()
    {
        
    }

    void ICommand.Undo()
    {
        if (undoData.Count <= 0) return;

        // save current transform here before applying undo
        TransformData _redoData = new TransformData();
        _redoData.position = this.transform.position;
        _redoData.rotation = this.transform.localEulerAngles;

        TransformData _undoData = undoData.Pop();

        ApplyTransformData(_undoData);

        redoData.Push(_redoData);
    }

    void ICommand.Redo()
    {
        if (redoData.Count <= 0) return;

        // save current transform here before applying redo
        TransformData _undoData = new TransformData();
        _undoData.position = this.transform.position;
        _undoData.rotation = this.transform.localEulerAngles;

        TransformData _redoData = redoData.Pop();
        ApplyTransformData(_redoData);

        undoData.Push(_undoData);
    }

    private void OnEnable()
    {
        interactable = GetComponent<ARSelectionInteractable>();
        // it's because of this additional event listener - this is triggered every time
        // a selection is made. Maybe combine the deletion logic here

        //interactable.onSelectEntered.AddListener(AddCommand); 
        //interactable.onSelectEntered.AddListener(SaveIsInPond);
        //interactable.onSelectExited.AddListener(TransformChecker); // Check if new transform allowed - if not, run undo

        //interactable.onSelectEntered.AddListener(TurnOffPlacer);
        //interactable.onSelectExited.AddListener(TurnOnPlacer);

        interactable.onSelectEntered.AddListener(SaveInitialTransformData);
        interactable.onSelectExited.AddListener(UpdateStack);
    }


    void SaveInitialTransformData(XRBaseInteractor arg)
    {
        TransformData data = new TransformData();
        data.position = this.transform.position;
        data.rotation = this.transform.localEulerAngles;
        data.tag = this.tag;
        data.objectInstance = this.gameObject;
        initialTransformData = data;

        ObjectStatus status = this.GetComponent<ObjectStatus>();

        originalIsInPond = status.isInPond;
    }


    private void UpdateStack(XRBaseInteractor arg)
    {
        CommandManager.ExecuteCommand(this);
        undoData.Push(initialTransformData);
        redoData.Clear();

        if (!CheckTransformChange()) { 
            CommandManager.Undo();
        }
    }

    private bool CheckTransformChange()
    {
        // Add threshold based comparison for position and rotation if needed
        ObjectStatus status = GetComponent<ObjectStatus>();

        if (status.isIntersecting || ((tag == "Fish" || tag == "Boat") && !status.isInPond) || status.isInPond != originalIsInPond)
        {
            return false;
        }

        if (Vector3.Distance(transform.position, initialTransformData.position) < 0.01f
            || Quaternion.Angle(Quaternion.Euler(transform.localEulerAngles),
            Quaternion.Euler(initialTransformData.rotation)) < 0.01f)
            return false;

        return true;
    }

    //private void checkTransform()
    //{
    //    ObjectStatus status = this.GetComponent<ObjectStatus>();
    //    // If intersecting another object
    //    if (status.isIntersecting)
    //    {
    //        // run undo
    //        CommandManager.Undo();
    //        return;
    //    }


    //    if ((tag == "Fish" || tag == "Boat") && !status.isInPond)
    //    {
    //        CommandManager.Undo();
    //        return;
    //    }


    //    if (status.isInPond != originalIsInPond)
    //    {
    //        CommandManager.Undo();
    //        return;
    //    }
    //}

    private void OnDisable()
    {
        //interactable.onSelectEntered.RemoveListener(AddCommand);
        //interactable.onSelectEntered.RemoveListener(SaveIsInPond);
        //interactable.onSelectExited.RemoveListener(TransformChecker);

        //interactable.onSelectEntered.RemoveListener(TurnOffPlacer);
        //interactable.onSelectExited.RemoveListener(TurnOnPlacer);
        interactable.onSelectEntered.RemoveListener(SaveInitialTransformData);
        interactable.onSelectExited.RemoveListener(UpdateStack);
    }

    void SaveIsInPond(XRBaseInteractor arg)
    {
        originalIsInPond = this.GetComponent<ObjectStatus>().isInPond;
    }

    void TransformChecker(XRBaseInteractor arg)
    {
        ObjectStatus status = this.GetComponent<ObjectStatus>();

        // If intersecting another object
        if (status.isIntersecting)
        {
            // run undo
            CommandManager.Undo();
            return;
        }


        if ((tag == "Fish" || tag == "Boat") && !status.isInPond)
        {
            CommandManager.Undo();
            return;
        }


        if (status.isInPond != originalIsInPond)
        {
            CommandManager.Undo();
            return;
        }

        // if the status is off- i.e., the object has been deleted then undo this.
        // The deletemanager will take care of the history in this case.

        // this solves the problem for 
        //if (!this.gameObject.activeInHierarchy)
        //{
        //    CommandManager.Undo();
        //    return;

        //    // need to deselect the object somehow
        //}

    }

    // Maybe create another checker - if the button was clicked;
    // then undo and then repush a new command. 

    void TurnOffPlacer(XRBaseInteractor arg)
    {
        placementInteractable.enabled = false;
    }

    void TurnOnPlacer(XRBaseInteractor arg)
    {
        placementInteractable.enabled = true;
    }

}

public struct TransformData
{
    public Vector3 position;
    public Vector3 rotation;

    public string tag;
    public GameObject objectInstance;

    // may need to store the prefab tag here
    // and in isPlaceable store the prefabs? 
}
*/