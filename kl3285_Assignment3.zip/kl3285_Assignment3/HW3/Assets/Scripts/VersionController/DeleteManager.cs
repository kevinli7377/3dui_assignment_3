using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.AR;

public class DeleteManager : MonoBehaviour, ICommand
{
    Stack<TransformData> undoData = new Stack<TransformData>();
    Stack<TransformData> redoData = new Stack<TransformData>();

    public GameObject _selectedObject;

    public XRInteractionManager xRInteractionManager;

    public ARPlacementInteractableExtended placementInteractable;

    public void Start()
    {
        xRInteractionManager = GameObject.FindGameObjectWithTag("XR").GetComponent<XRInteractionManager>();
    }

    public void Delete()
    {
        if (!_selectedObject) return;

        CommandManager.ExecuteCommand(this);

        TransformData _undoData = new TransformData();

        _selectedObject.SetActive(false);

        // Get the original position upon selecting the object from TransformUndo
        TransformData initialTransformData = _selectedObject.GetComponent<TransformUndo>().initialTransformData;

        _undoData.position = initialTransformData.position;
        _undoData.rotation = initialTransformData.rotation;
        _undoData.tag = _selectedObject.tag;
        _undoData.objectInstance = _selectedObject;

        // unregister the interactor

        // TODO: Test if unregistering the interactor and interactable works
        //ARSelectionInteractableExtended selected_interactable = _selectedObject.GetComponent<ARSelectionInteractableExtended>();
        //xRInteractionManager.UnregisterInteractable(selected_interactable);

        // maybe consider adding in original isInPond state into the struct

        //_undoData.position = _selectedObject.transform.position;
        //_undoData.rotation = _selectedObject.transform.localEulerAngles;
        //_undoData.tag = _selectedObject.tag;
        //_undoData.objectInstance = _selectedObject;

        undoData.Push(_undoData);
        redoData.Clear();

        _selectedObject = null;

        placementInteractable.enabled = true;
        //UnregisterInteractable(_selectedObject);
    }


    // ICOMMAND
    public void Execute()
    {
    }

    void RegisterInteractable(GameObject obj) // TODO: Added
    { 
        ARSelectionInteractableExtended selected_interactable = obj.GetComponent<ARSelectionInteractableExtended>();
        xRInteractionManager.RegisterInteractable(selected_interactable);
    }


    void UnregisterInteractable(GameObject obj) // TODO: Added
    {
        ARSelectionInteractableExtended selected_interactable = obj.GetComponent<ARSelectionInteractableExtended>();
        xRInteractionManager.UnregisterInteractable(selected_interactable);
    }

    public void Undo()
    {
        if (undoData.Count > 0)
        {
            // BUG - if translate then delete, the original position is not saved.
            // Need to get the position from the selection interactables

            // Bug


            TransformData _undoData = undoData.Pop();

            _undoData.objectInstance.SetActive(true);

            _selectedObject = _undoData.objectInstance;

            // should also apply the original transforms
            _selectedObject.transform.position = _undoData.position;
            _selectedObject.transform.localEulerAngles = _undoData.rotation;

            TransformData initialTransformData = _selectedObject.GetComponent<TransformUndo>().initialTransformData;

            _undoData.position = initialTransformData.position;
            _undoData.rotation = initialTransformData.rotation;
            _undoData.tag = _selectedObject.tag;
            _undoData.objectInstance = _selectedObject;

            redoData.Push(_undoData);

            //RegisterInteractable(_selectedObject); // TODO: Added
            placementInteractable.enabled = true;
        }
    }

    public void Redo()
    {
        if (redoData.Count > 0)
        {
            TransformData _redoData = redoData.Pop();

            _redoData.objectInstance.SetActive(false);
            undoData.Push(_redoData);

            _selectedObject = _redoData.objectInstance;

            _selectedObject.transform.position = _redoData.position;
            _selectedObject.transform.localEulerAngles = _redoData.rotation;

            TransformData initialTransformData = _selectedObject.GetComponent<TransformUndo>().initialTransformData;

            _redoData.position = initialTransformData.position;
            _redoData.rotation = initialTransformData.rotation;
            _redoData.tag = _selectedObject.tag;
            _redoData.objectInstance = _selectedObject;

            //UnregisterInteractable(_selectedObject); // TODO: Added
            placementInteractable.enabled = true;

            _selectedObject = null;
        }
    }
}
