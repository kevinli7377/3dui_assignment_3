using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.Interaction.Toolkit.AR;
using UnityEngine.XR.Interaction.Toolkit;
using TMPro;
using System;

// consider turning off plane manager? 

public class isPlaceable : MonoBehaviour, ICommand
{
    Stack<TransformData> undoData = new Stack<TransformData>();
    Stack<TransformData> redoData = new Stack<TransformData>();

    public ARPlacementInteractableExtended interactable;

    public List<GameObject> prefabs;

    //public TextMeshProUGUI text;

    void Start()
    {
        Debug.Log("Started");
        //text = GameObject.FindGameObjectWithTag("Debug").GetComponent<TextMeshProUGUI>();
        //text.text = "Found text in canvas - isplaceable";
    }

    void AddCommand(ARPlacementInteractable arg0, GameObject arg1)
    {
        CommandManager.ExecuteCommand(this);

        TransformData data = new TransformData();
        data.position = arg1.transform.position;
        data.rotation = arg1.transform.localEulerAngles;
        data.tag = arg1.tag;
        data.objectInstance = arg1;

        undoData.Push(data);
        redoData.Clear();

        //text.text += "\n Adding Command-Placement";
    }

    void ICommand.Execute()
    {
        
    }

    void ICommand.Undo()
    {
        if (undoData.Count <= 0) return;

        TransformData _undoData = undoData.Pop();
        _undoData.objectInstance.SetActive(false);
        redoData.Push(_undoData);

    }


    void ICommand.Redo()
    {
        if (redoData.Count <= 0) return;

        TransformData _redoData = redoData.Pop();
        _redoData.objectInstance.SetActive(true);
        undoData.Push(_redoData);

    }


    void TransformChecker(ARPlacementInteractable arg0, GameObject arg1)
    {

        ObjectStatus status = arg1.GetComponent<ObjectStatus>(); // isInPond, isIntersecting

        int pondCount = GameObject.FindGameObjectsWithTag("Pond").Length;
        int boatCount = GameObject.FindGameObjectsWithTag("Boat").Length;

        // 1. Spawn pond first
        if (pondCount == 0 && !arg1.CompareTag("Pond"))
        {
            //text.text += "1";
            CommandManager.Undo();
            return;
        }


        // 2. Check if pond already exists
        if (pondCount > 1 && arg1.CompareTag("Pond"))
        {
            //text.text += "2";
            CommandManager.Undo();
            return;
        }


        //// 4. If boat doesn't exist, need to spawn boat before anything else:
        if (pondCount == 1 && boatCount == 0 && !arg1.CompareTag("Boat") && !arg1.CompareTag("Pond"))
        {
            //text.text = "A boat must be placed second.";
            CommandManager.Undo();
            return;
        }


        // 5. Check if boat already exists
        if (arg1.CompareTag("Boat"))
        {
            // Check if exists in scene, if so, destory this instance
            if (boatCount > 1)
            {
                //text.text += "3";
                CommandManager.Undo();
                return;
            }
        }

        // . Check if reference already exists
        if (arg1.CompareTag("Reference"))
        {
            StartCoroutine(DelayedReferenceCheck(arg1));
        }

        IEnumerator DelayedReferenceCheck(GameObject arg1)
        {
            yield return new WaitForSeconds(0.1f); 

            int referenceCount = GameObject.FindGameObjectsWithTag("Reference").Length;

            ObjectStatus status = arg1.GetComponent<ObjectStatus>();

            if (status.isInPond || referenceCount > 1)
            {
                //text.text += "\nReference in pond or more than 1, undoing...";
                CommandManager.Undo();
            }
            else
            {
                //text.text += "\nReference placed successfully.";
            }
        }

        // 5. If fish or boat

        // Replace the direct check in TransformChecker with:
        if (arg1.CompareTag("Fish") || arg1.CompareTag("Boat"))
        {
            StartCoroutine(DelayedCheck(status));
            return; // You might need to adjust logic based on how your checks should proceed
        }


        // Delay check to ensure trigger has activated
        IEnumerator DelayedCheck(ObjectStatus status)
        {
            yield return new WaitForSeconds(0.1f); // Adjust the delay as needed
            if (!status.isInPond)
            {
                //text.text += "5";
                CommandManager.Undo();
            }
        }


        // 6. If intersecting another object
        //if (status.isIntersecting)
        //{
        //    //text.text += "6";
        //    //// run undo
        //    //CommandManager.Undo();
        //    return;
        //}

        // Delay check to ensure trigger has activated
        IEnumerator DelayedCheckIntersecting(ObjectStatus status)
        {
            yield return new WaitForSeconds(0.1f); // Adjust the delay as needed
            if (status.isIntersecting)
            {
                //text.text += "6";
                CommandManager.Undo();
            }
        }

        DelayedCheckIntersecting(status);
    }

    private void OnEnable()
    {
        //text.text += "\n On-Enabl";
        interactable = GetComponent<ARPlacementInteractableExtended>();

        interactable.onObjectPlaced.AddListener(AddCommand);
        interactable.onObjectPlaced.AddListener(TransformChecker); // Deletes placed object if object does not satisfy requirements
    }


    private void OnDisable()
    {
        interactable.onObjectPlaced.RemoveListener(AddCommand);
        interactable.onObjectPlaced.RemoveListener(TransformChecker);
    }

    //public GameObject getPrefabByTag(string tag)
    //{
    //    if (tag == "Pond") {
    //        return prefabs[0];
    //    }

    //    if (tag == "Reference")
    //    {
    //        return prefabs[1];
    //    }

    //    if (tag == "Rock")
    //    {
    //        return prefabs[2];
    //    }

    //    if (tag == "Fish")
    //    {
    //        return prefabs[3];
    //    }

    //    if (tag == "Boat")
    //    {
    //        return prefabs[4];
    //    }

    //    if (tag == "Can")
    //    {
    //        return prefabs[5];
    //    }

    //    if (tag == "Bottle")
    //    {
    //        return prefabs[6];
    //    }

    //    return null;
    //}

}

