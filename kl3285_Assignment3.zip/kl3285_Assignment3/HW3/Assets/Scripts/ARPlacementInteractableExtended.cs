using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.Interaction.Toolkit.AR;

public class ARPlacementInteractableExtended : ARPlacementInteractable
{
    public GameObject MyPlaceObject(Pose pose)
    {
        return PlaceObject(pose);
    }


    //protected override GameObject PlaceObject(Pose pose)
    //{
    //    base.PlaceObject(pose);
    //}

    //public CommandManager commandManager;

    // Internal class for redo and undo functionality
    //public class PlaceObjectCommand : ICommand
    //{
    //    private GameObject objectToPlace;
    //    private GameObject placedObject;

    //    private Vector3 position;
    //    private Quaternion rotation;



    //    // May need to store the original posittions etc.

    //    public PlaceObjectCommand(GameObject objectToPlace, Vector3 position, Quaternion rotation)
    //    {
    //        this.objectToPlace = objectToPlace;
    //        this.position = position;
    //        this.rotation = rotation;

    //        // might have to store the prefabs publicly as a list and also store the tag instead?
    //    }

    //    public void Execute()
    //    {
    //        if (placedObject == null)
    //        {
    //            placedObject = GameObject.Instantiate(objectToPlace, position, rotation);
    //        }
    //    }

    //    public void Undo()
    //    {
    //        if (placedObject != null)
    //        {
    //            GameObject.Destroy(placedObject);
    //            placedObject = null;
    //        }
    //    }

    //}

    //protected override void OnObjectPlaced(ARObjectPlacementEventArgs args)
    //{
    //    base.OnObjectPlaced(args);  // Call the base method

    //    // 1. Need to make sure that pond is spawned first:
    //    GameObject existingPond = GameObject.FindGameObjectWithTag("Pond");
    //    if (!existingPond)
    //    {
    //        Destroy(args.placementObject);
    //        return;
    //    }

    //    // 2. Limit one pond
    //    if (args.placementObject.CompareTag("Pond"))
    //    {
    //        // Check if pool already exists in scene, if so, destory this instance
    //        if (existingPond != null && existingPond != args.placementObject)
    //        {
    //            Destroy(args.placementObject);
    //            return;
    //        }
    //    }

    //    // 3. Limit one reference object
    //    if (args.placementObject.CompareTag("Reference"))
    //    {
    //        GameObject existingReference = GameObject.FindGameObjectWithTag("Reference");
    //        if (existingReference != null && existingReference != args.placementObject)
    //        {
    //            Destroy(args.placementObject);
    //            return;
    //        }
    //    }

    //    // 3. Limit one boat object
    //    if (args.placementObject.CompareTag("Boat"))
    //    {
    //        GameObject existingBoat = GameObject.FindGameObjectWithTag("Boat");
    //        if (existingBoat!= null && existingBoat!= args.placementObject)
    //        {
    //            Destroy(args.placementObject);
    //            return;
    //        }
    //    }


    // 4. Limit placement to pool
    //if (args.placementObject.CompareTag("Fish") || args.placementObject.CompareTag("Boat"))
    //{
    //    StartCoroutine(DelayedCheck(args.placementObject,0.1f));
    //}
    //else
    //{
    //    //AppendToCommandManager(args.placementObject);
    //}

    // If all tests are passed, register the action to CommandManager
    // TODO: Need to update this - will not work in its current state

    //if (spawnable)
    //{
    //    ICommand placeCommand = new PlaceObjectCommand(
    //        args.placementObject,
    //        args.placementObject.transform.position,
    //        args.placementObject.transform.rotation
    //        );

    //    commandManager.ExecuteCommand(placeCommand);
    //}
    //}

    //private void AppendToCommandManager(GameObject obj) // Append CommandManager
    //{
    //    if (obj)
    //    {
    //        ICommand placeCommand = new PlaceObjectCommand(
    //            obj,
    //            obj.transform.position,
    //            obj.transform.rotation
    //            );

    //        commandManager.ExecuteCommand(placeCommand);
    //    }
    //}

    //private IEnumerator DelayedCheck(GameObject obj, float delay)
    //{
    //    yield return new WaitForSeconds(delay);

    //    ObjectStatus objstatus = obj.GetComponent<ObjectStatus>();
    //    if (objstatus != null && !objstatus.isInPond)
    //    {
    //        Destroy(obj);
    //    } else
    //    {
    //        AppendToCommandManager(obj);
    //    }
    //}
}


