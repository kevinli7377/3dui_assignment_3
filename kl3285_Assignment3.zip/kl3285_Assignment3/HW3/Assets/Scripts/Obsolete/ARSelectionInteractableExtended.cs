using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit.AR;

public class ARSelectionInteractableExtended : ARSelectionInteractable
{

    public void undoSelection()
    {
        //if(m_GestureSelected)
        //{

        //}
    }

    //public Button deleteButton;


    //public void DeleteSelectedObject()
    //{
    //    if (m_GestureSelected && gameObject != null)
    //    {
    //        m_GestureSelected = false; // Deselect
    //        if (m_SectionVisualization != null)
    //        {
    //            m_SelectionVisualization.SetActive(false);
    //        }

    //        Destroy(gameObject);

    //    }
    //}
}
