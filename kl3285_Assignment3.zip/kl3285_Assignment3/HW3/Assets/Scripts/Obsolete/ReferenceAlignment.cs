using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ReferenceAlignment : MonoBehaviour
{

    //private ARTrackedImageManager trackedImageManager;
    //public GameObject saveButton;

    //public GameObject virtualReference;

    //// SHould start tracking once a virtualReference has been placed

    //private void Start()
    //{
    //    trackedImageManager = GetComponent<ARTrackedImageManager>();
    //}

    //private void OnEnable()
    //{
    //    trackedImageManager.trackedImagesChanged += OnTrackedImagesChanged;
    //}

    //private void OnDisable()
    //{
    //    trackedImageManager.trackedImagesChanged -= OnTrackedImagesChanged;
    //}

    //private void OnTrackedImagesChanged(ARTrackedImagesChangedEventArgs eventArgs)
    //{
    //    if (virtualReference == null)
    //    {
    //        return;
    //    }

    //    foreach (var newImage in eventArgs.added)
    //    {
    //        if(newImage.referenceImage.name == "S24_marker_tex")
    //        {
    //            CheckAlignment(newImage,virtualReference);
    //        }
    //    }

    //    foreach (var newImage in eventArgs.updated)
    //    {
    //        if (newImage.referenceImage.name == "S24_marker_tex")
    //        {
    //            CheckAlignment(newImage, virtualReference);
    //        }
    //    }


    //    foreach (var newImage in eventArgs.removed)
    //    {
    //        if (newImage.referenceImage.name == "S24_marker_tex")
    //        {
    //            HideSaveButton();
    //        }
    //    }
    //}

    //public void SetVirtualReference(GameObject newReference)
    //{
    //    virtualReference = newReference;
    //}

    //private void ShowSaveButton()
    //{
    //    saveButton.SetActive(true);
    //}

    //private void HideSaveButton()
    //{
    //    saveButton.SetActive(false);
    //}

    //private void CheckAlignment(ARTrackedImage trackedImage, GameObject virtualObject)
    //{
    //    float alignmentThreshold = 0.1f;

    //    if (Vector3.Distance(trackedImage.transform.position, virtualObject.transform.position) < alignmentThreshold)
    //    {
    //        ShowSaveButton();
    //    }
    //    else
    //    {
    //        HideSaveButton();
    //    }
    //}
}
