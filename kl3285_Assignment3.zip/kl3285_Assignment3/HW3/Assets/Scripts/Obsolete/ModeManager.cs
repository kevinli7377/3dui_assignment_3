using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using TMPro;


// OBSOLETE - NOT BEING USED


public class ModeManager : MonoBehaviour
{

    List<string> modes = new List<string>{ "Placement", "Edit", "Delete" };

    public GameObject placementManager; // should be ARPlacementInteractable object
    public TMP_Dropdown dropdown;

    
    public string currentMode;

    void Start()
    {
        currentMode = modes[0]; // set to placement mode on default
    }

    // on value change for dropdown, change the mode

    public void ChangeMode()
    {
        Debug.Log(dropdown.value); // always 0...
        currentMode = modes[dropdown.value]; // update mode

        if (currentMode == "Placement")
        {
            TurnOnPlacement();
            TurnOffSelectability();
            ExitDeleteMode();
        }

        if (currentMode == "Edit")
        {
            TurnOffPlacement();
            TurnOnSelectability();
            ExitDeleteMode();
        }

        if (currentMode == "Delete")
        {
            TurnOffPlacement();
            TurnOnSelectability();
            EnterDeleteMode();
        }
    }

    void TurnOnPlacement()
    {
        // set active status of placement manager to on
        placementManager.SetActive(true);
    }

    void TurnOffPlacement()
    {
        // set active status of placement manager to off
        placementManager.SetActive(false);
    }

    void TurnOnSelectability()
    {
        // iterate through all scene objects and turn on selection
        // if the scene object has a ObjectStatus or if it has a AR Selection interactable
        // then turn off the Seletabla

        ARSelectionInteractableExtended[] objects = FindObjectsOfType<ARSelectionInteractableExtended>();

        foreach (ARSelectionInteractableExtended obj in objects)
        {
            obj.enabled = true;
        }

    }

    void TurnOffSelectability()
    {
        // iterate through all scene objects and turn off selection
        ARSelectionInteractableExtended[] objects = FindObjectsOfType<ARSelectionInteractableExtended>();

        foreach(ARSelectionInteractableExtended obj in objects)
        {
            obj.enabled = false;
        }

    }

    void EnterDeleteMode()
    {
        // iterate through all scene objects and turn on transformdelete
        TransformDelete[] objects = FindObjectsOfType<TransformDelete>();

        foreach (TransformDelete obj in objects)
        {
            obj.enabled = true;
        }
    }

    void ExitDeleteMode()
    {
        // iterate through all scene objects and turn off transformdelete
        TransformDelete[] objects = FindObjectsOfType<TransformDelete>();

        foreach (TransformDelete obj in objects)
        {
            obj.enabled = false;
        }
    }

}
