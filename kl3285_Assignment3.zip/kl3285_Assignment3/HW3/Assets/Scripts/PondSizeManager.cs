using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using TMPro;
using UnityEngine.XR.Interaction.Toolkit.AR;
using System;

public class PondSizeManager : MonoBehaviour
{
    // Apply scale to pond prefab
    public GameObject pondSliderObject;
    private Slider slider;

    public ARPlacementInteractableExtended aRPlacementInteractable;

    public TMP_Dropdown dropdown;


    private void Start()
    {        
        slider = pondSliderObject.GetComponent<Slider>();
    }

    private void OnEnable()
    {
        aRPlacementInteractable.onObjectPlaced.AddListener(OnObjectPlacedCheck);
    }

    private void OnDisable()
    {
        aRPlacementInteractable.onObjectPlaced.RemoveListener(OnObjectPlacedCheck);
    }

    private void OnObjectPlacedCheck(ARPlacementInteractable arg0, GameObject obj)
    {
        if (!obj.CompareTag("Pond")) return;

        //originalScale = obj.transform.localScale;

        Vector3 updatedScale = new Vector3{};
        updatedScale.x = obj.transform.localScale.x * slider.value;
        updatedScale.y = obj.transform.localScale.y;
        updatedScale.z = obj.transform.localScale.z * slider.value;
        obj.transform.localScale = updatedScale;
    }


    public void ToggleSliderActiveStatus()
    {
        if (dropdown.value == 0)
        {
            pondSliderObject.SetActive(true);
        } else
        {
            pondSliderObject.SetActive(false);
        }
    }

}
