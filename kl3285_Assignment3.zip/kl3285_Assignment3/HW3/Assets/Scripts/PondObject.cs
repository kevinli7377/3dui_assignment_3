using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PondObject : MonoBehaviour
{
    //private bool isInPond = false;
    ////private bool instantiated = false;

    //private void Start()
    //{
    //    isInPond = false;
    //    // Doesn't work
    //}

    //private void OnTriggerEnter(Collider other)
    //{
    //    if (other.CompareTag("Pond"))
    //    {
    //        isInPond = true;
    //    }
    //}

    //private void OnTriggerExit(Collider other)
    //{
    //    if (other.CompareTag("Pond"))
    //    {
    //        isInPond = false;
    //        //Destroy(gameObject);
    //    }
    //}

    //private void Update()
    //{
    //    if (!isInPond)
    //    {
    //        Destroy(gameObject);
    //    }
    //}

    ////private void
}
