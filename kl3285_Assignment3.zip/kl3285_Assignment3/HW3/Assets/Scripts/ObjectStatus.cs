using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectStatus : MonoBehaviour
{

    public bool isInPond;
    public bool isIntersecting; // if is colliding other object

    // Start is called before the first frame update

    void Start()
    {
        isInPond = false;
        isIntersecting = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter(UnityEngine.Collider other)
    {
        if (other.CompareTag("Pond"))
        {
            isInPond = true;
        }

        if (other.CompareTag("Fish")||
            other.CompareTag("Boat")||
            other.CompareTag("Bottle")||
            other.CompareTag("Can") ||
            other.CompareTag("Rock") ||
            other.CompareTag("Reference"))
        {
            isIntersecting = true;
        }
    }

    private void OnTriggerExit(UnityEngine.Collider other)
    {
        if (other.CompareTag("Pond"))
        {
            isInPond = false;
        }

        if (other.CompareTag("Fish") ||
            other.CompareTag("Boat") ||
            other.CompareTag("Bottle") ||
            other.CompareTag("Can") ||
            other.CompareTag("Rock") ||
            other.CompareTag("Reference"))
        {
            isIntersecting = false;
        }
    }

}
