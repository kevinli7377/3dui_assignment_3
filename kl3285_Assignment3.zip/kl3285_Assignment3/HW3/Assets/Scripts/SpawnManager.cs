using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.EventSystems;

using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Unity.XR.CoreUtils;
using TMPro;

using UnityEngine.XR.Interaction.Toolkit.AR;

public class SpawnManager : MonoBehaviour
{

    public List<GameObject> spawnableObjects;
    public TMP_Dropdown dropdown;

    public GameObject spawnableObject;

    public ARPlacementInteractable arPlacementInteractable;

    //public ReferenceAlignment referenceAlignmentScript;

    private void Start()
    {
        arPlacementInteractable.placementPrefab = spawnableObject;
    }

    public void UpdateSpawnableObject()
    {
        int index = dropdown.value; // Get selected dropdown value
        if (index >= 0 && index < spawnableObjects.Count)
        {
            spawnableObject = spawnableObjects[dropdown.value]; //update the selected object
        }

        arPlacementInteractable.placementPrefab = spawnableObject;
    }
}



















/*
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.EventSystems;

using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Unity.XR.CoreUtils;
using TMPro;

using UnityEngine.XR.Interaction.Toolkit.AR;

public class SpawnManager : MonoBehaviour
{

    public List<GameObject> spawnableObjects;
    public TMP_Dropdown dropdown;

    public GameObject spawnableObject;

    //public ARRaycastManager raycastManager;
    //public ARPlaneManager planeManager;

    //private List<ARRaycastHit> raycastHits = new List<ARRaycastHit>();

    public ARPlacementInteractable arPlacementInteractable;


    private void Start()
    {
        arPlacementInteractable.placementPrefab = spawnableObject;
    }

    //private void Update()
    //{
    //    // Check for touch inputs

    //    if (Input.touchCount > 0)
    //    {
    //        if(Input.GetTouch(0).phase == TouchPhase.Began)
    //        {
    //            bool collision = raycastManager.Raycast(Input.GetTouch(0).position, raycastHits,
    //                TrackableType.PlaneWithinPolygon);
    //            // Check if ray hit the plane

    //            if (collision && !isDropdownOrButtonPressed() && canSpawn(Input.GetTouch(0).position, spawnableObject)) // Check if button is not being pressed
    //            {
    //                GameObject spawnedObject = Instantiate(spawnableObject);
    //                spawnedObject.transform.SetPositionAndRotation(raycastHits[0].pose.position, raycastHits[0].pose.rotation);

    //                // need to implement case where the 
    //            }
    //        } 
    //    }
    //}

    // pool needs to be spawned before any other object

    // Function to prevent accidental placements when pressing button
    //public bool isDropdownOrButtonPressed()
    //{
    //    if (EventSystem.current.currentSelectedGameObject?.GetComponentInParent<TMP_Dropdown>() == null
    //        && EventSystem.current.currentSelectedGameObject?.GetComponent<Button>() == null)
    //    {
    //        return false;
    //    }

    //    return true;
    //}

    public void UpdateSpawnableObject()
    {
        int index = dropdown.value; // Get selected dropdown value
        if (index >= 0 && index < spawnableObjects.Count)
        {
            spawnableObject = spawnableObjects[dropdown.value]; //update the selected object
        }

        arPlacementInteractable.placementPrefab = spawnableObject;
    }

    //public bool canSpawn(Vector3 position, GameObject objectToSpawn)
    //{
    //    // 1. if player is trying to spawn something before pool
    //    if (GameObject.FindGameObjectsWithTag("Pond").Length == 0 && !objectToSpawn.CompareTag("Pond"))
    //    {
    //        return false;
    //    }

    //    // 2. Check if a pond already exists
    //    if (objectToSpawn.CompareTag("Pond")){
    //        if (GameObject.FindGameObjectsWithTag("Pond").Length > 0)
    //        {
    //            Debug.Log("A pond already exists");
    //            return false;
    //        }
    //        else
    //        {
    //            return true;
    //        }
    //    }

    // 3. If the object is a Fish or Boat, ensure it is in pond

    // Theres a bug here
    //if (objectToSpawn.CompareTag("Fish") || objectToSpawn.CompareTag("Boat") || objectToSpawn.CompareTag("Buoy"))
    //{
    //GameObject pond = GameObject.FindGameObjectWithTag("Pond");
    //if (GameObject.FindGameObjectsWithTag("Pond").Length > 0)
    //{
    //Collider pondCollider = pond.GetComponent<Collider>();
    //Ray ray = Camera.main.ScreenPointToRay(position);
    //RaycastHit hitInfo;

    //if (Physics.Raycast(ray, out hitInfo))
    //{
    //    if (hitInfo.collider.gameObject.CompareTag("Pond")){
    //        return true
    //    }
    //}
    //}
    //return false;


    // Check if the object

    // Boat should be within the circular boundaries of the pool
    //}

    // 3. Check that instantiated object will not intserect other objects - to be handled by individual scripts?
    // i.e., should the individula prefabs contain anti-collision scripts?



    //    return true;
    //}

}
*/